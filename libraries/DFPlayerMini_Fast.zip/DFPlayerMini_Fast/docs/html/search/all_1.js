var searchData=
[
  ['currenteq',['currentEQ',['../class_d_f_player_mini___fast.html#a33932dfa1833fee0f4871456360269e1',1,'DFPlayerMini_Fast']]],
  ['currentflashtrack',['currentFlashTrack',['../class_d_f_player_mini___fast.html#a5e4d9834d4690d35e4288ba35c535e42',1,'DFPlayerMini_Fast']]],
  ['currentmode',['currentMode',['../class_d_f_player_mini___fast.html#aaa84d372d162eb2cad48733aecccef91',1,'DFPlayerMini_Fast']]],
  ['currentsdtrack',['currentSdTrack',['../class_d_f_player_mini___fast.html#a7b36cd1e98dbd208fbff4ba27dc2e181',1,'DFPlayerMini_Fast']]],
  ['currentusbtrack',['currentUsbTrack',['../class_d_f_player_mini___fast.html#ab462f27de3dcf48ef2bbd04e87097ec2',1,'DFPlayerMini_Fast']]],
  ['currentversion',['currentVersion',['../class_d_f_player_mini___fast.html#a1161e2387a4411fea258ac4b44730d53',1,'DFPlayerMini_Fast']]],
  ['currentvolume',['currentVolume',['../class_d_f_player_mini___fast.html#a224d402554831895a99346f7bf3c3de5',1,'DFPlayerMini_Fast']]]
];
